"""Discover closed (finalized) session directories under data_root."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Iterable, List, Optional, Sequence

log = logging.getLogger("ml_upload.flights")

# Defaults match DataLogger StorageManager::finalize_current_session()
DEFAULT_DIR_PREFIX = "flight_"
DEFAULT_CLOSED_MARKER = "flight_metadata.json"
DEFAULT_BUSY_MARKERS = ("telemetry.db-wal", "telemetry.db-shm")


def is_closed_flight(
    flight_dir: Path,
    closed_marker: str = DEFAULT_CLOSED_MARKER,
    busy_markers: Sequence[str] = DEFAULT_BUSY_MARKERS,
) -> bool:
    """
    A session is closed when the finalize marker exists and no busy files remain.

    Active recording sessions lack the closed marker; if any busy_marker file
    is present we treat the directory as still in use.
    """
    if not flight_dir.is_dir():
        return False
    if not (flight_dir / closed_marker).is_file():
        return False
    for name in busy_markers:
        if name and (flight_dir / name).exists():
            log.debug("skip %s: %s present", flight_dir.name, name)
            return False
    return True


def list_closed_flights(
    flights_root: str | Path,
    dir_prefix: str = DEFAULT_DIR_PREFIX,
    closed_marker: str = DEFAULT_CLOSED_MARKER,
    busy_markers: Optional[Iterable[str]] = None,
) -> List[Path]:
    """Return closed session dirs, oldest first (by directory name / mtime)."""
    root = Path(flights_root)
    if not root.is_dir():
        log.warning("data_root does not exist: %s", root)
        return []

    markers: Sequence[str]
    if busy_markers is None:
        markers = DEFAULT_BUSY_MARKERS
    else:
        markers = tuple(m for m in busy_markers if m)

    candidates: List[Path] = []
    for child in root.iterdir():
        if not child.is_dir():
            continue
        if dir_prefix and not child.name.startswith(dir_prefix):
            continue
        if is_closed_flight(
            child, closed_marker=closed_marker, busy_markers=markers
        ):
            candidates.append(child)

    candidates.sort(key=lambda p: (p.name, p.stat().st_mtime))
    return candidates
