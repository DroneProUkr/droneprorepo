"""Create and remove tar.zst archives of flight directories / batches."""

from __future__ import annotations

import json
import logging
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Optional

from upload_service.batch_planner import (
    BATCH_SIDECAR_NAME,
    DEFAULT_CLOSED_MARKER,
    BatchPlan,
)

log = logging.getLogger("ml_upload.archive")


def _require_zstd() -> str:
    path = shutil.which("zstd")
    if not path:
        raise RuntimeError(
            "zstd not found in PATH; install with: sudo apt-get install -y zstd"
        )
    return path


def _run_tar_zstd(tar_args: list[str], archive_path: Path) -> None:
    """Pipe tar stdout into zstd; raise RuntimeError on failure."""
    _require_zstd()
    zstd_cmd = ["zstd", "-T1", "-q", "-o", str(archive_path)]
    tar_cmd = ["tar", *tar_args]

    tar_proc = subprocess.Popen(
        tar_cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    zstd_proc = subprocess.Popen(
        zstd_cmd,
        stdin=tar_proc.stdout,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if tar_proc.stdout:
        tar_proc.stdout.close()

    try:
        _, zstd_err = zstd_proc.communicate()
        tar_err = tar_proc.stderr.read() if tar_proc.stderr else b""
        tar_rc = tar_proc.wait()
    finally:
        if tar_proc.stderr:
            tar_proc.stderr.close()
        if zstd_proc.stdout:
            zstd_proc.stdout.close()
        if zstd_proc.stderr:
            zstd_proc.stderr.close()

    if tar_rc != 0 or zstd_proc.returncode != 0:
        if archive_path.exists():
            archive_path.unlink(missing_ok=True)
        raise RuntimeError(
            f"archive failed: tar_rc={tar_rc} zstd_rc={zstd_proc.returncode} "
            f"tar_err={tar_err.decode(errors='replace')!r} "
            f"zstd_err={zstd_err.decode(errors='replace')!r}"
        )

    size = archive_path.stat().st_size
    if size < 1:
        archive_path.unlink(missing_ok=True)
        raise RuntimeError(f"archive is empty: {archive_path}")


def create_flight_archive(flight_dir: Path, work_dir: Path) -> Path:
    """
    Archive entire flight_dir into work_dir/<flight_name>.tar.zst.

    The archive root contains the flight folder name (flight_YYYYMMDD_HHMMSS/...).
    """
    if not flight_dir.is_dir():
        raise FileNotFoundError(f"flight directory not found: {flight_dir}")

    work_dir.mkdir(parents=True, exist_ok=True)
    archive_path = work_dir / f"{flight_dir.name}.tar.zst"
    if archive_path.exists():
        archive_path.unlink()

    log.info("archiving %s -> %s", flight_dir, archive_path)
    _run_tar_zstd(
        ["-C", str(flight_dir.parent), "-cf", "-", flight_dir.name],
        archive_path,
    )
    log.info("archive ready %s (%d bytes)", archive_path, archive_path.stat().st_size)
    return archive_path


def create_batch_archive(
    flight_dir: Path,
    work_dir: Path,
    batch: BatchPlan,
    closed_marker: str = DEFAULT_CLOSED_MARKER,
) -> Path:
    """
    Archive one batch: listed files + closed marker + sidecar under flight_name/.

    Output: work_dir/<flight_name>/<batch.filename>
    """
    flight_dir = Path(flight_dir)
    if not flight_dir.is_dir():
        raise FileNotFoundError(f"flight directory not found: {flight_dir}")

    flight_name = flight_dir.name
    out_dir = Path(work_dir) / flight_name
    out_dir.mkdir(parents=True, exist_ok=True)
    archive_path = out_dir / batch.filename
    if archive_path.exists():
        archive_path.unlink()

    # Paths to include (relative to flight_dir), unique and ordered
    include: list[str] = []
    seen: set[str] = set()

    def add(rel: str) -> None:
        if rel not in seen:
            seen.add(rel)
            include.append(rel)

    for rel in batch.files:
        add(rel)
    if closed_marker and (flight_dir / closed_marker).is_file():
        add(closed_marker)

    sidecar_payload = {
        "flight": flight_name,
        "batch_index": batch.batch_index,
        "batch_count": batch.batch_count,
        "batch_id": batch.id,
        "files": list(batch.files),
    }

    with tempfile.TemporaryDirectory(prefix="ml-upload-batch-") as tmp:
        staging_root = Path(tmp)
        staging_flight = staging_root / flight_name
        staging_flight.mkdir(parents=True)

        for rel in include:
            src = flight_dir / rel
            if not src.is_file():
                raise FileNotFoundError(f"batch file missing: {src}")
            dest = staging_flight / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dest)

        sidecar_path = staging_flight / BATCH_SIDECAR_NAME
        sidecar_path.write_text(
            json.dumps(sidecar_payload, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )

        log.info(
            "archiving batch %s (%d files) -> %s",
            batch.id,
            len(batch.files),
            archive_path,
        )
        _run_tar_zstd(
            ["-C", str(staging_root), "-cf", "-", flight_name],
            archive_path,
        )

    log.info(
        "batch archive ready %s (%d bytes)",
        archive_path,
        archive_path.stat().st_size,
    )
    return archive_path


def remove_flight_and_archive(
    flight_dir: Path,
    archive_path: Optional[Path] = None,
    work_subdir: Optional[Path] = None,
) -> None:
    """Delete local flight directory and temporary archive(s) after successful upload."""
    if archive_path is not None and archive_path.exists():
        archive_path.unlink()
        log.info("removed archive %s", archive_path)
    if work_subdir is not None and work_subdir.exists():
        shutil.rmtree(work_subdir)
        log.info("removed work dir %s", work_subdir)
    if flight_dir.exists():
        shutil.rmtree(flight_dir)
        log.info("removed flight directory %s", flight_dir)


def remove_archive_file(archive_path: Path) -> None:
    """Delete a single temp archive after its batch completed."""
    if archive_path.exists():
        archive_path.unlink()
        log.info("removed archive %s", archive_path)
