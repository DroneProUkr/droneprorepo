"""Plan size-balanced archive batches for a closed flight directory."""

from __future__ import annotations

import hashlib
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Sequence

log = logging.getLogger("ml_upload.batch_planner")

# Sidecar written into every archive; not part of the source file walk for packing
# content, but metadata marker is always included separately by the archiver.
BATCH_SIDECAR_NAME = "_ml_upload_batch.json"
DEFAULT_CLOSED_MARKER = "flight_metadata.json"


@dataclass
class FileEntry:
    relpath: str
    size: int
    mtime_ns: int


@dataclass
class BatchPlan:
    """One archive slice of a flight."""

    id: str
    filename: str
    batch_index: int
    batch_count: int
    files: List[str] = field(default_factory=list)
    uncompressed_bytes: int = 0


@dataclass
class FlightPlan:
    flight_name: str
    plan_hash: str
    batches: List[BatchPlan]


def list_flight_files(flight_dir: Path) -> List[FileEntry]:
    """List all regular files under flight_dir with paths relative to flight_dir."""
    if not flight_dir.is_dir():
        raise FileNotFoundError(f"flight directory not found: {flight_dir}")

    entries: List[FileEntry] = []
    for path in sorted(flight_dir.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(flight_dir).as_posix()
        # Sidecar is generated at archive time; ignore if left over from a prior run
        if rel == BATCH_SIDECAR_NAME or rel.endswith("/" + BATCH_SIDECAR_NAME):
            continue
        st = path.stat()
        entries.append(
            FileEntry(relpath=rel, size=st.st_size, mtime_ns=st.st_mtime_ns)
        )
    entries.sort(key=lambda e: e.relpath)
    return entries


def compute_plan_hash(files: Sequence[FileEntry]) -> str:
    """Stable hash of sorted relpath+size+mtime for resume invalidation."""
    h = hashlib.sha256()
    for e in files:
        h.update(e.relpath.encode("utf-8"))
        h.update(b"\0")
        h.update(str(e.size).encode("ascii"))
        h.update(b"\0")
        h.update(str(e.mtime_ns).encode("ascii"))
        h.update(b"\n")
    return h.hexdigest()


def _batch_id(index: int, count: int) -> str:
    return f"b{index:02d}of{count:02d}"


def _batch_filename(flight_name: str, index: int, count: int) -> str:
    return f"{flight_name}_{_batch_id(index, count)}.tar.zst"


def _pack_size_balanced(
    files: Sequence[FileEntry], batch_count: int
) -> List[List[FileEntry]]:
    """
    Assign files into batch_count bins using largest-first into the currently
    smallest bin (size-balanced multiway partition).
    """
    bins: List[List[FileEntry]] = [[] for _ in range(batch_count)]
    bin_sizes = [0] * batch_count

    ordered = sorted(files, key=lambda e: (-e.size, e.relpath))
    for entry in ordered:
        target = min(range(batch_count), key=lambda i: (bin_sizes[i], i))
        bins[target].append(entry)
        bin_sizes[target] += entry.size

    # Drop empty bins (should not happen when batch_count <= len(files))
    non_empty = [b for b in bins if b]
    # Stable order: by first file relpath in each bin for deterministic numbering
    for b in non_empty:
        b.sort(key=lambda e: e.relpath)
    non_empty.sort(key=lambda b: b[0].relpath)
    return non_empty


def plan_flight_batches(
    flight_dir: Path,
    target_batch_count: int = 10,
) -> FlightPlan:
    """
    Build up to ``target_batch_count`` size-balanced batches for ``flight_dir``.

    ``target_batch_count`` of 0 or 1 yields a single archive with all files.
    N = min(target, file_count); files are never split across archives.
    """
    flight_dir = Path(flight_dir)
    flight_name = flight_dir.name
    files = list_flight_files(flight_dir)
    if not files:
        raise RuntimeError(f"no files to upload in {flight_dir}")

    plan_hash = compute_plan_hash(files)
    target = int(target_batch_count)
    if target <= 1:
        n = 1
        bins = [list(files)]
    else:
        n = min(target, len(files))
        bins = _pack_size_balanced(files, n)

    batches: List[BatchPlan] = []
    count = len(bins)
    for i, bin_files in enumerate(bins, start=1):
        rels = [e.relpath for e in bin_files]
        batches.append(
            BatchPlan(
                id=_batch_id(i, count),
                filename=_batch_filename(flight_name, i, count),
                batch_index=i,
                batch_count=count,
                files=rels,
                uncompressed_bytes=sum(e.size for e in bin_files),
            )
        )

    log.info(
        "planned %d batch(es) for %s (%d files, hash=%s…)",
        count,
        flight_name,
        len(files),
        plan_hash[:12],
    )
    return FlightPlan(flight_name=flight_name, plan_hash=plan_hash, batches=batches)
