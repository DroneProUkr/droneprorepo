"""Durable upload manifest for multi-archive flights with multipart checkpoints."""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from upload_service.batch_planner import BatchPlan, FlightPlan

log = logging.getLogger("ml_upload.state")

STATUS_PENDING = "pending"
STATUS_UPLOADING = "uploading"
STATUS_UPLOADED = "uploaded"


@dataclass
class MultipartCheckpoint:
    key: str
    upload_id: str
    part_size: int
    parts: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "key": self.key,
            "upload_id": self.upload_id,
            "part_size": self.part_size,
            "parts": list(self.parts),
        }

    @classmethod
    def from_dict(cls, data: Optional[Dict[str, Any]]) -> Optional["MultipartCheckpoint"]:
        if not data:
            return None
        return cls(
            key=str(data["key"]),
            upload_id=str(data["upload_id"]),
            part_size=int(data["part_size"]),
            parts=list(data.get("parts") or []),
        )


@dataclass
class BatchState:
    id: str
    filename: str
    batch_index: int
    batch_count: int
    files: List[str]
    status: str = STATUS_PENDING
    remote_id: Optional[int] = None
    multipart: Optional[MultipartCheckpoint] = None

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {
            "id": self.id,
            "filename": self.filename,
            "batch_index": self.batch_index,
            "batch_count": self.batch_count,
            "files": list(self.files),
            "status": self.status,
        }
        if self.remote_id is not None:
            d["remote_id"] = self.remote_id
        if self.multipart is not None:
            d["multipart"] = self.multipart.to_dict()
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BatchState":
        return cls(
            id=str(data["id"]),
            filename=str(data["filename"]),
            batch_index=int(data.get("batch_index") or 0),
            batch_count=int(data.get("batch_count") or 0),
            files=list(data.get("files") or []),
            status=str(data.get("status") or STATUS_PENDING),
            remote_id=data.get("remote_id"),
            multipart=MultipartCheckpoint.from_dict(data.get("multipart")),
        )

    def to_batch_plan(self) -> BatchPlan:
        return BatchPlan(
            id=self.id,
            filename=self.filename,
            batch_index=self.batch_index,
            batch_count=self.batch_count,
            files=list(self.files),
        )


@dataclass
class UploadManifest:
    flight: str
    plan_hash: str
    batches: List[BatchState]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "flight": self.flight,
            "plan_hash": self.plan_hash,
            "batches": [b.to_dict() for b in self.batches],
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "UploadManifest":
        return cls(
            flight=str(data["flight"]),
            plan_hash=str(data["plan_hash"]),
            batches=[BatchState.from_dict(b) for b in data.get("batches") or []],
        )

    @classmethod
    def from_flight_plan(cls, plan: FlightPlan) -> "UploadManifest":
        batches = [
            BatchState(
                id=b.id,
                filename=b.filename,
                batch_index=b.batch_index,
                batch_count=b.batch_count,
                files=list(b.files),
                status=STATUS_PENDING,
            )
            for b in plan.batches
        ]
        return cls(flight=plan.flight_name, plan_hash=plan.plan_hash, batches=batches)

    def all_uploaded(self) -> bool:
        return bool(self.batches) and all(
            b.status == STATUS_UPLOADED for b in self.batches
        )

    def find_batch(self, batch_id: str) -> Optional[BatchState]:
        for b in self.batches:
            if b.id == batch_id:
                return b
        return None


def manifest_path(work_dir: Path, flight_name: str) -> Path:
    return Path(work_dir) / flight_name / "manifest.json"


def load_manifest(path: Path) -> Optional[UploadManifest]:
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return UploadManifest.from_dict(data)
    except (OSError, json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
        log.warning("failed to load manifest %s: %s", path, exc)
        return None


def save_manifest(path: Path, manifest: UploadManifest) -> None:
    """Atomic write: write temp file then rename."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(manifest.to_dict(), indent=2, sort_keys=True) + "\n"
    fd, tmp_name = None, None
    try:
        fd, tmp_name = _mktemp_in_dir(path.parent)
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fd = None
            fh.write(payload)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp_name, path)
        tmp_name = None
    finally:
        if fd is not None:
            try:
                os.close(fd)
            except OSError:
                pass
        if tmp_name is not None and os.path.exists(tmp_name):
            try:
                os.unlink(tmp_name)
            except OSError:
                pass
    log.debug("saved manifest %s", path)


def _mktemp_in_dir(directory: Path) -> tuple[int, str]:
    import tempfile

    return tempfile.mkstemp(prefix=".manifest.", suffix=".tmp", dir=str(directory))


def mark_batch_uploading(
    manifest: UploadManifest,
    batch_id: str,
    checkpoint: MultipartCheckpoint,
) -> None:
    batch = manifest.find_batch(batch_id)
    if batch is None:
        raise KeyError(f"unknown batch id: {batch_id}")
    batch.status = STATUS_UPLOADING
    batch.multipart = checkpoint


def update_multipart_parts(
    manifest: UploadManifest,
    batch_id: str,
    parts: List[Dict[str, Any]],
    key: str,
    upload_id: str,
    part_size: int,
) -> None:
    batch = manifest.find_batch(batch_id)
    if batch is None:
        raise KeyError(f"unknown batch id: {batch_id}")
    batch.status = STATUS_UPLOADING
    batch.multipart = MultipartCheckpoint(
        key=key,
        upload_id=upload_id,
        part_size=part_size,
        parts=list(parts),
    )


def mark_batch_uploaded(
    manifest: UploadManifest,
    batch_id: str,
    remote_id: Optional[int] = None,
) -> None:
    batch = manifest.find_batch(batch_id)
    if batch is None:
        raise KeyError(f"unknown batch id: {batch_id}")
    batch.status = STATUS_UPLOADED
    batch.remote_id = remote_id
    batch.multipart = None
