"""S3 multipart upload client via ML Upload API (presigned part URLs)."""

from __future__ import annotations

import json
import logging
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

log = logging.getLogger("ml_upload.api")

# S3 minimum part size (except last part)
MIN_PART_BYTES = 5 * 1024 * 1024
DEFAULT_PART_BYTES = 8 * 1024 * 1024
MAX_PARTS = 10_000


class _NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    """Enrollment credentials must never be forwarded to a redirect target."""

    def redirect_request(self, *_args, **_kwargs):
        return None


def _open_without_redirect(req: urllib.request.Request, timeout: float):
    opener = urllib.request.build_opener(_NoRedirectHandler())
    return opener.open(req, timeout=timeout)


def _validate_header_value(value: str, name: str, *, allow_empty: bool = False) -> None:
    if not isinstance(value, str):
        raise TypeError(f"{name} must be a string")
    if (not allow_empty and not value) or "\r" in value or "\n" in value:
        raise ValueError(f"{name} must be a non-empty single-line string")


class AuthError(Exception):
    """401 — device not registered / inactive / bad credentials."""


class ApiError(Exception):
    def __init__(self, status: int, body: str, message: str = ""):
        self.status = status
        self.body = body
        super().__init__(message or f"API error {status}: {body[:200]}")


class EnrollmentStatus(str, Enum):
    """Outcomes defined by ``POST /ml_upload/enroll``."""

    APPROVED = "approved"
    PENDING = "pending"
    REJECTED = "rejected"
    ALREADY_CLAIMED = "already_claimed"


@dataclass(frozen=True)
class EnrollmentResult:
    """A validated enrollment response.

    ``device_token`` deliberately does not appear in ``repr`` so logging a result
    cannot disclose the newly issued credential.
    """

    status: EnrollmentStatus
    http_status: int
    device_token: Optional[str] = field(default=None, repr=False)
    project: Optional[str] = None


@dataclass
class PartETag:
    part_number: int
    etag: str


@dataclass
class MultipartResumeState:
    """Checkpoint for resuming an in-progress multipart upload."""

    key: str
    upload_id: str
    part_size: int
    parts: List[PartETag] = field(default_factory=list)

    def parts_as_dicts(self) -> List[Dict[str, Any]]:
        return [{"part_number": p.part_number, "etag": p.etag} for p in self.parts]


CheckpointCallback = Callable[[MultipartResumeState], None]


def normalize_etag(raw: Optional[str]) -> str:
    """Return ETag including surrounding double quotes as required by complete."""
    if raw is None:
        return ""
    value = raw.strip()
    if value.startswith("W/"):
        value = value[2:].strip()
    if len(value) >= 2 and value[0] == '"' and value[-1] == '"':
        return value
    if value and not value.startswith('"'):
        return f'"{value}"'
    return value


def _parts_from_checkpoint(
    parts: Optional[List[Any]],
) -> List[PartETag]:
    if not parts:
        return []
    result: List[PartETag] = []
    for p in parts:
        if isinstance(p, PartETag):
            result.append(p)
        elif isinstance(p, dict):
            result.append(
                PartETag(
                    part_number=int(p["part_number"]),
                    etag=normalize_etag(str(p.get("etag") or "")),
                )
            )
        else:
            raise TypeError(f"unsupported part checkpoint entry: {type(p)}")
    result.sort(key=lambda x: x.part_number)
    return result


class MlUploadClient:
    def __init__(
        self,
        api_base_url: str,
        serial: str,
        token: str,
        timeout: float = 60.0,
        part_retries: int = 3,
    ):
        _validate_header_value(serial, "device serial")
        _validate_header_value(token, "device token", allow_empty=True)
        self.base = api_base_url.rstrip("/")
        self.serial = serial
        self._token = token
        self.timeout = timeout
        self.part_retries = part_retries

    def _auth_headers(self) -> Dict[str, str]:
        return {
            "X-Device-Serial": self.serial,
            "X-Device-Token": self._token,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    def _request_json(
        self,
        method: str,
        path: str,
        payload: Optional[Dict[str, Any]] = None,
        expect_empty: bool = False,
    ) -> Any:
        url = f"{self.base}{path}"
        data = None
        headers = self._auth_headers()
        if payload is not None:
            data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            with _open_without_redirect(req, timeout=self.timeout) as resp:
                body = resp.read()
                if expect_empty or not body:
                    return None
                return json.loads(body.decode("utf-8"))
        except urllib.error.HTTPError as exc:
            try:
                err_body = exc.read().decode("utf-8", errors="replace")
            except Exception:
                err_body = ""
            finally:
                try:
                    exc.close()
                except Exception:
                    pass
            if exc.code == 401:
                raise AuthError(
                    "Unauthorized (401): device serial/token not registered or inactive"
                ) from None
            raise ApiError(exc.code, err_body) from None

    def enroll(
        self,
        master_key: str,
        project: Optional[str] = None,
    ) -> EnrollmentResult:
        """Enroll this device with a fleet master key.

        Enrollment uses the master key only for this request; it never replaces
        the personal token held by this client. Expected protocol outcomes are
        returned as :class:`EnrollmentResult` so callers can distinguish pending,
        rejected, approved, and already-claimed devices without parsing errors.
        """
        _validate_header_value(self.serial, "device serial")
        _validate_header_value(master_key, "master key")
        if project is not None and not isinstance(project, str):
            raise TypeError("project must be a string or None")
        if project is not None and ("\r" in project or "\n" in project):
            raise ValueError("project must be a single-line string")

        payload: Dict[str, str] = {}
        if project:
            payload["project"] = project

        url = f"{self.base}/ml_upload/enroll"
        parsed = urllib.parse.urlsplit(url)
        is_loopback_http = parsed.scheme == "http" and parsed.hostname in {
            "127.0.0.1",
            "::1",
            "localhost",
        }
        if parsed.scheme != "https" and not is_loopback_http:
            raise ValueError("enrollment requires HTTPS (HTTP is allowed on loopback only)")
        if parsed.username is not None or parsed.password is not None:
            raise ValueError("enrollment URL must not contain user information")
        headers = {
            "X-Device-Serial": self.serial,
            "X-Device-Token": master_key,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        req = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers=headers,
            method="POST",
        )

        try:
            with _open_without_redirect(req, timeout=self.timeout) as resp:
                http_status = resp.status
                body = resp.read()
        except urllib.error.HTTPError as exc:
            http_status = exc.code
            # Consume and close the response, but do not retain an enrollment
            # error body: it is untrusted and may echo submitted credentials.
            try:
                exc.read()
            except Exception:
                pass
            finally:
                try:
                    exc.close()
                except Exception:
                    pass
            body = b""

        if http_status == 401:
            return EnrollmentResult(
                status=EnrollmentStatus.ALREADY_CLAIMED,
                http_status=http_status,
            )
        if http_status == 403:
            return EnrollmentResult(
                status=EnrollmentStatus.REJECTED,
                http_status=http_status,
            )
        if http_status not in (200, 202):
            raise ApiError(
                http_status,
                "",
                f"enrollment API error {http_status}",
            )

        try:
            result = json.loads(body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise ApiError(
                http_status,
                "",
                "invalid enrollment response: expected JSON object",
            ) from None
        if not isinstance(result, dict):
            raise ApiError(
                http_status,
                "",
                "invalid enrollment response: expected JSON object",
            )

        if http_status == 202:
            if result.get("status") != EnrollmentStatus.PENDING.value:
                raise ApiError(
                    http_status,
                    "",
                    "invalid enrollment response: expected pending status",
                )
            return EnrollmentResult(
                status=EnrollmentStatus.PENDING,
                http_status=http_status,
            )

        device_token = result.get("device_token")
        approved_project = result.get("project")
        if (
            result.get("status") != EnrollmentStatus.APPROVED.value
            or not isinstance(device_token, str)
            or not device_token
            or "\r" in device_token
            or "\n" in device_token
            or not isinstance(approved_project, str)
            or not approved_project
            or "\r" in approved_project
            or "\n" in approved_project
        ):
            raise ApiError(
                http_status,
                "",
                "invalid enrollment response: approved result requires "
                "device_token and project",
            )
        device_token = device_token.strip()
        approved_project = approved_project.strip()
        if not device_token or not approved_project:
            raise ApiError(
                http_status,
                "",
                "invalid enrollment response: approved values cannot be blank",
            )
        return EnrollmentResult(
            status=EnrollmentStatus.APPROVED,
            http_status=http_status,
            device_token=device_token,
            project=approved_project,
        )

    def initiate(
        self, filename: str, content_type: Optional[str] = None
    ) -> Dict[str, str]:
        payload: Dict[str, Any] = {"filename": filename}
        if content_type:
            payload["content_type"] = content_type
        result = self._request_json("POST", "/ml_upload/initiate", payload)
        if not isinstance(result, dict) or "upload_id" not in result or "key" not in result:
            raise ApiError(0, str(result), "invalid initiate response")
        return result

    def part_url(self, key: str, upload_id: str, part_number: int) -> str:
        result = self._request_json(
            "POST",
            "/ml_upload/part-url",
            {
                "key": key,
                "upload_id": upload_id,
                "part_number": part_number,
            },
        )
        if not isinstance(result, dict) or "url" not in result:
            raise ApiError(0, str(result), "invalid part-url response")
        return result["url"]

    def put_part(self, url: str, data: bytes) -> str:
        req = urllib.request.Request(
            url,
            data=data,
            method="PUT",
            headers={"Content-Length": str(len(data))},
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                etag = normalize_etag(resp.headers.get("ETag"))
                if not etag:
                    raise ApiError(resp.status, "", "S3 PUT response missing ETag")
                return etag
        except urllib.error.HTTPError as exc:
            try:
                err_body = exc.read().decode("utf-8", errors="replace")
            finally:
                exc.close()
            raise ApiError(exc.code, err_body, f"S3 PUT failed: {exc.code}") from None

    def complete(
        self,
        key: str,
        upload_id: str,
        filename: str,
        parts: List[PartETag],
        project: Optional[str] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "key": key,
            "upload_id": upload_id,
            "filename": filename,
            "parts": [
                {"part_number": p.part_number, "etag": p.etag} for p in parts
            ],
        }
        # Optional admin sorting label; server defaults to "Odometry" if omitted.
        if project:
            payload["project"] = project
        result = self._request_json("POST", "/ml_upload/complete", payload)
        if not isinstance(result, dict):
            raise ApiError(0, str(result), "invalid complete response")
        return result

    def abort(self, key: str, upload_id: str) -> None:
        try:
            self._request_json(
                "POST",
                "/ml_upload/abort",
                {"key": key, "upload_id": upload_id},
                expect_empty=True,
            )
        except AuthError:
            raise
        except ApiError as exc:
            log.warning("abort failed for upload_id=%s: %s", upload_id, exc)

    def upload_file(
        self,
        file_path: Path,
        content_type: Optional[str] = None,
        part_size: int = DEFAULT_PART_BYTES,
        project: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Full multipart flow: initiate → parts → complete.

        On failure after initiate, attempts abort. Prefer
        ``upload_file_resumable`` when checkpoints must survive interruptions.
        """
        try:
            return self.upload_file_resumable(
                file_path,
                content_type=content_type,
                part_size=part_size,
                project=project,
                resume=None,
                on_checkpoint=None,
                abort_on_failure=True,
            )
        except AuthError:
            raise

    def upload_file_resumable(
        self,
        file_path: Path,
        content_type: Optional[str] = None,
        part_size: int = DEFAULT_PART_BYTES,
        project: Optional[str] = None,
        resume: Optional[MultipartResumeState] = None,
        on_checkpoint: Optional[CheckpointCallback] = None,
        abort_on_failure: bool = False,
    ) -> Dict[str, Any]:
        """
        Multipart upload with optional resume checkpoint.

        Does not abort on transient failure when ``abort_on_failure`` is False
        (default), so callers can persist state and retry later.
        """
        if part_size < MIN_PART_BYTES:
            raise ValueError(f"part_size must be >= {MIN_PART_BYTES} bytes")

        filename = file_path.name
        file_size = file_path.stat().st_size
        if file_size < 1:
            raise ValueError(f"refusing to upload empty file: {file_path}")

        if resume is not None:
            if resume.part_size != part_size:
                raise ValueError(
                    f"checkpoint part_size {resume.part_size} != {part_size}"
                )
            key = resume.key
            upload_id = resume.upload_id
            parts = _parts_from_checkpoint(resume.parts)
            log.info(
                "resuming upload filename=%s upload_id=%s completed_parts=%d",
                filename,
                upload_id,
                len(parts),
            )
        else:
            init = self.initiate(filename, content_type=content_type)
            upload_id = init["upload_id"]
            key = init["key"]
            parts = []
            log.info(
                "initiated upload filename=%s size=%d upload_id=%s project=%s",
                filename,
                file_size,
                upload_id,
                project or "(server default)",
            )
            state = MultipartResumeState(
                key=key, upload_id=upload_id, part_size=part_size, parts=[]
            )
            if on_checkpoint:
                on_checkpoint(state)

        # Completed parts 1..N are full-sized (except a finished last part).
        n_done = len(parts)
        offset = n_done * part_size
        if offset > file_size:
            raise ApiError(
                0,
                "",
                f"checkpoint offset {offset} exceeds file size {file_size}",
            )
        if offset == file_size and parts:
            return self._complete_with_retry(
                key, upload_id, filename, parts, project=project
            )

        part_number = n_done + 1
        try:
            with open(file_path, "rb") as fh:
                if offset:
                    fh.seek(offset)
                while True:
                    if part_number > MAX_PARTS:
                        raise ApiError(0, "", f"exceeded max parts ({MAX_PARTS})")
                    chunk = fh.read(part_size)
                    if not chunk:
                        break
                    etag = self._upload_part_with_retry(
                        key, upload_id, part_number, chunk
                    )
                    parts.append(PartETag(part_number=part_number, etag=etag))
                    log.info(
                        "uploaded part %d/%s (%d bytes)",
                        part_number,
                        filename,
                        len(chunk),
                    )
                    if on_checkpoint:
                        on_checkpoint(
                            MultipartResumeState(
                                key=key,
                                upload_id=upload_id,
                                part_size=part_size,
                                parts=list(parts),
                            )
                        )
                    part_number += 1

            if not parts:
                raise ApiError(0, "", "no parts uploaded")

            return self._complete_with_retry(
                key, upload_id, filename, parts, project=project
            )
        except AuthError:
            if abort_on_failure:
                self.abort(key, upload_id)
            raise
        except Exception:
            if abort_on_failure:
                self.abort(key, upload_id)
            raise

    def _complete_with_retry(
        self,
        key: str,
        upload_id: str,
        filename: str,
        parts: List[PartETag],
        project: Optional[str] = None,
    ) -> Dict[str, Any]:
        last_exc: Optional[Exception] = None
        for attempt in range(1, self.part_retries + 1):
            try:
                meta = self.complete(
                    key, upload_id, filename, parts, project=project
                )
                log.info(
                    "upload complete filename=%s id=%s size_bytes=%s project=%s",
                    filename,
                    meta.get("id"),
                    meta.get("size_bytes"),
                    project or "(server default)",
                )
                return meta
            except AuthError:
                raise
            except (ApiError, OSError, urllib.error.URLError) as exc:
                last_exc = exc
                log.warning("complete attempt %d failed: %s", attempt, exc)
                time.sleep(min(2 ** attempt, 30))
        assert last_exc is not None
        raise last_exc

    def _upload_part_with_retry(
        self,
        key: str,
        upload_id: str,
        part_number: int,
        chunk: bytes,
    ) -> str:
        last_exc: Optional[Exception] = None
        for attempt in range(1, self.part_retries + 1):
            try:
                url = self.part_url(key, upload_id, part_number)
                return self.put_part(url, chunk)
            except AuthError:
                raise
            except (ApiError, OSError, urllib.error.URLError) as exc:
                last_exc = exc
                log.warning(
                    "part %d attempt %d failed: %s",
                    part_number,
                    attempt,
                    exc,
                )
                time.sleep(min(2 ** attempt, 30))
        assert last_exc is not None
        raise last_exc
