"""Network helpers: Wi-Fi SSID, Ethernet link, and API reachability."""

from __future__ import annotations

import logging
import shutil
import subprocess
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional

log = logging.getLogger("ml_upload.network")

VALID_NETWORK_MODES = frozenset({"wifi", "ethernet", "any"})


@dataclass(frozen=True)
class UploadNetworkStatus:
    """Result of upload_conditions_met()."""

    ok: bool
    mode: str
    ssid: Optional[str]
    ethernet_iface: Optional[str]
    api_ok: bool
    reason: str


def _run_cmd(args: list[str], timeout: float = 5.0) -> Optional[str]:
    try:
        proc = subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        log.debug("command %s failed: %s", args, exc)
        return None
    if proc.returncode != 0:
        return None
    return (proc.stdout or "").strip()


def normalize_network_mode(raw: Optional[str]) -> str:
    """Return wifi | ethernet | any (default wifi)."""
    mode = (raw or "wifi").strip().lower()
    if mode in VALID_NETWORK_MODES:
        return mode
    log.warning("unknown network_mode=%r; using wifi", raw)
    return "wifi"


def get_current_ssid() -> Optional[str]:
    """Return the active Wi-Fi SSID, or None if unknown / not associated."""
    if shutil.which("nmcli"):
        out = _run_cmd(
            ["nmcli", "-t", "-f", "ACTIVE,SSID", "dev", "wifi"],
            timeout=5.0,
        )
        if out:
            for line in out.splitlines():
                # ACTIVE:SSID  e.g. yes:HomeBase  or  yes:My\:SSID
                if not line.startswith("yes:"):
                    continue
                ssid = line[4:].replace("\\:", ":")
                if ssid:
                    return ssid

        # Fallback: connection show --active
        out = _run_cmd(
            ["nmcli", "-t", "-f", "NAME,TYPE", "connection", "show", "--active"],
            timeout=5.0,
        )
        if out:
            for line in out.splitlines():
                if ":802-11-wireless" in line or line.endswith(":wifi"):
                    name = line.split(":", 1)[0]
                    if name:
                        return name

    if shutil.which("iwgetid"):
        out = _run_cmd(["iwgetid", "-r"], timeout=5.0)
        if out:
            return out

    if shutil.which("iw"):
        out = _run_cmd(["iw", "dev"], timeout=5.0)
        if out:
            for line in out.splitlines():
                line = line.strip()
                if line.startswith("ssid "):
                    ssid = line[5:].strip()
                    if ssid:
                        return ssid

    return None


def get_connected_ethernet_iface() -> Optional[str]:
    """
    Return the first connected Ethernet interface name, or None.

    Prefers NetworkManager; falls back to sysfs (non-wireless, operstate=up,
    carrier=1 when available).
    """
    if shutil.which("nmcli"):
        out = _run_cmd(
            ["nmcli", "-t", "-f", "DEVICE,TYPE,STATE", "device", "status"],
            timeout=5.0,
        )
        if out:
            for line in out.splitlines():
                parts = line.split(":")
                if len(parts) < 3:
                    continue
                dev, typ, state = parts[0], parts[1], parts[2]
                if typ == "ethernet" and state == "connected" and dev:
                    return dev

    net = Path("/sys/class/net")
    if not net.is_dir():
        return None
    for p in sorted(net.iterdir()):
        name = p.name
        if name == "lo" or (p / "wireless").exists():
            continue
        try:
            # ARPHRD_ETHER == 1
            if (p / "type").read_text().strip() != "1":
                continue
            if (p / "operstate").read_text().strip() != "up":
                continue
            carrier = p / "carrier"
            if carrier.exists() and carrier.read_text().strip() != "1":
                continue
            return name
        except OSError:
            continue
    return None


def ssid_allowed(current: Optional[str], allowlist: Iterable[str]) -> bool:
    if not current:
        return False
    allowed = {s for s in allowlist if s}
    return current in allowed


def api_reachable(api_base_url: str, timeout: float = 3.0) -> bool:
    """
    Light probe: TCP/HTTP reachability of the API host.

    Any HTTP response (including 401/404) counts as reachable; connection
    errors / timeouts do not.
    """
    base = api_base_url.rstrip("/") + "/"
    # Prefer HEAD; some stacks reject HEAD — fall back to GET.
    for method in ("HEAD", "GET"):
        req = urllib.request.Request(base, method=method)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                _ = resp.status
            return True
        except urllib.error.HTTPError:
            # Server responded — network path is fine.
            return True
        except urllib.error.URLError as exc:
            log.debug("%s %s failed: %s", method, base, exc)
            continue
        except OSError as exc:
            log.debug("%s %s failed: %s", method, base, exc)
            continue
    return False


def upload_conditions_met(
    api_base_url: str,
    ssid_allowlist: Iterable[str],
    network_mode: str = "wifi",
    timeout: float = 3.0,
) -> UploadNetworkStatus:
    """
    Decide whether uploads may proceed.

    network_mode:
      wifi     — active SSID in allowlist AND API reachable (legacy default)
      ethernet — connected Ethernet iface AND API reachable
      any      — API reachable only (no local-link policy)
    """
    mode = normalize_network_mode(network_mode)
    ssid = get_current_ssid()
    eth = get_connected_ethernet_iface()

    if mode == "wifi":
        if not ssid_allowed(ssid, ssid_allowlist):
            return UploadNetworkStatus(
                ok=False,
                mode=mode,
                ssid=ssid,
                ethernet_iface=eth,
                api_ok=False,
                reason="ssid not allowlisted or unknown",
            )
        api_ok = api_reachable(api_base_url, timeout=timeout)
        return UploadNetworkStatus(
            ok=api_ok,
            mode=mode,
            ssid=ssid,
            ethernet_iface=eth,
            api_ok=api_ok,
            reason="ok" if api_ok else "api unreachable",
        )

    if mode == "ethernet":
        if not eth:
            return UploadNetworkStatus(
                ok=False,
                mode=mode,
                ssid=ssid,
                ethernet_iface=None,
                api_ok=False,
                reason="no connected ethernet interface",
            )
        api_ok = api_reachable(api_base_url, timeout=timeout)
        return UploadNetworkStatus(
            ok=api_ok,
            mode=mode,
            ssid=ssid,
            ethernet_iface=eth,
            api_ok=api_ok,
            reason="ok" if api_ok else "api unreachable",
        )

    # mode == "any"
    api_ok = api_reachable(api_base_url, timeout=timeout)
    return UploadNetworkStatus(
        ok=api_ok,
        mode=mode,
        ssid=ssid,
        ethernet_iface=eth,
        api_ok=api_ok,
        reason="ok" if api_ok else "api unreachable",
    )
