"""Standalone ML data upload service (session dirs -> S3 via multipart API)."""

__version__ = "1.3.0"
