"""Load uploader configuration and resolve/persist device credentials."""

from __future__ import annotations

import ast
import logging
import os
import secrets
import stat
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List

try:  # Python 3.11+
    import tomllib
except ModuleNotFoundError:  # pragma: no cover - supported images use 3.11+
    tomllib = None  # type: ignore[assignment]

log = logging.getLogger("ml_upload.credentials")

VALID_SERIAL_SOURCES = frozenset(
    {"config_toml_v2", "config_ini", "machine_id"}
)
DEFAULT_CONFIG_TOML = Path("/root/config.toml")
DEFAULT_CONFIG_INI = Path("/root/config.ini")


def load_config(path: str | Path) -> Dict[str, str]:
    """Parse a simple key=value config file (comments and blank lines ignored)."""
    cfg: Dict[str, str] = {}
    with open(path, encoding="utf-8") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "=" not in line:
                continue
            key, value = line.split("=", 1)
            cfg[key.strip()] = value.strip()
    return cfg


def parse_ssid_allowlist(raw: str) -> List[str]:
    return [s.strip() for s in raw.split(",") if s.strip()]


@dataclass(frozen=True)
class Credentials:
    serial: str
    token: str


def _read_stripped(path: Path) -> str | None:
    if not path.is_file():
        return None
    text = path.read_text(encoding="utf-8").strip()
    return text or None


def read_secret(path: str | Path) -> str | None:
    """Read a non-empty secret file without ever logging its contents."""
    return _read_stripped(Path(path))


def read_private_secret(path: str | Path) -> str | None:
    """Read a regular, non-symlink secret that is inaccessible to group/others."""
    secret_path = Path(path)
    try:
        info = secret_path.lstat()
    except FileNotFoundError:
        return None
    except OSError as exc:
        log.error("cannot inspect secret file %s: %s", secret_path, exc)
        return None
    if not stat.S_ISREG(info.st_mode) or secret_path.is_symlink():
        log.error("refusing non-regular or symlink secret file: %s", secret_path)
        return None
    if stat.S_IMODE(info.st_mode) & 0o077:
        log.error("secret file must not be accessible by group/others: %s", secret_path)
        return None
    try:
        value = _read_stripped(secret_path)
    except OSError as exc:
        log.error("cannot read secret file %s: %s", secret_path, exc)
        return None
    if not value or "\n" in value or "\r" in value:
        log.error("secret file must contain exactly one non-empty line: %s", secret_path)
        return None
    return value


def _fsync_directory(path: Path) -> None:
    flags = os.O_RDONLY
    if hasattr(os, "O_DIRECTORY"):
        flags |= os.O_DIRECTORY
    fd = os.open(path, flags)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def _atomic_write_text(path: Path, text: str, mode: int) -> None:
    """Atomically replace a text file and make the replacement durable."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    tmp_path = Path(tmp_name)
    try:
        os.fchmod(fd, mode)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            fd = -1
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, path)
        os.chmod(path, mode)
        _fsync_directory(path.parent)
    finally:
        if fd >= 0:
            os.close(fd)
        try:
            tmp_path.unlink(missing_ok=True)
        except OSError:
            pass


def write_secret(path: str | Path, value: str) -> None:
    """Persist a secret as a durable, root-only file."""
    if not value or "\n" in value or "\r" in value:
        raise ValueError("secret must be a non-empty single line")
    _atomic_write_text(Path(path), value + "\n", 0o600)


def update_config_value(path: str | Path, key: str, value: str) -> None:
    """Replace one key=value entry while preserving the rest of upload.conf."""
    if not key or any(ch in key for ch in "=\r\n"):
        raise ValueError("invalid config key")
    if "\n" in value or "\r" in value:
        raise ValueError("config values must be a single line")

    config_path = Path(path)
    original = config_path.read_text(encoding="utf-8")
    lines = original.splitlines(keepends=True)
    replacement = f"{key}={value}\n"
    found = False
    output: list[str] = []
    for raw in lines:
        stripped = raw.strip()
        if stripped and not stripped.startswith("#") and "=" in raw:
            current_key = raw.split("=", 1)[0].strip()
            if current_key == key:
                output.append(replacement)
                found = True
                continue
        output.append(raw)

    if not found:
        if output and not output[-1].endswith(("\n", "\r")):
            output[-1] += "\n"
        output.append(replacement)

    mode = config_path.stat().st_mode & 0o777
    _atomic_write_text(config_path, "".join(output), mode)


def persist_enrollment(
    config_path: str | Path,
    serial_path: str | Path,
    token_path: str | Path,
    serial: str,
    project: str,
    device_token: str,
    *,
    pending_serial_path: str | Path | None = None,
) -> None:
    """
    Commit an approved enrollment before the first authenticated initiate.

    Project is persisted first.  The token is the final commit marker because its
    presence suppresses future enrollment attempts.
    """
    if not project or "\n" in project or "\r" in project:
        raise ValueError("approved project must be a non-empty single line")
    update_config_value(config_path, "project", project)
    write_secret(serial_path, serial)
    write_secret(token_path, device_token)
    if pending_serial_path is not None:
        remove_file_durable(pending_serial_path)


def remove_file_durable(path: str | Path) -> None:
    """Remove a state file and durably record the directory update."""
    target = Path(path)
    try:
        target.unlink()
    except FileNotFoundError:
        return
    _fsync_directory(target.parent)


def _machine_id_short() -> str:
    for candidate in (Path("/etc/machine-id"), Path("/var/lib/dbus/machine-id")):
        if candidate.is_file():
            mid = candidate.read_text(encoding="utf-8").strip()
            if mid:
                return mid[:12]
    return secrets.token_hex(6)


def _machine_id() -> str | None:
    """Return the complete stable machine-id; never invent one for baked mode."""
    for candidate in (Path("/etc/machine-id"), Path("/var/lib/dbus/machine-id")):
        try:
            mid = _read_stripped(candidate)
        except OSError:
            continue
        if mid:
            return mid
    return None


def _read_config_toml_serial(path: Path) -> str | None:
    if not path.is_file():
        return None
    try:
        if tomllib is not None:
            with path.open("rb") as f:
                document: Dict[str, Any] = tomllib.load(f)
            drone = document.get("drone")
        else:  # Minimal Python 3.10 fallback for the two activation string keys.
            drone = _read_drone_table_fallback(path)
    except (OSError, ValueError, SyntaxError) as exc:
        log.warning("serial source %s is not ready: %s", path, exc)
        return None

    if not isinstance(drone, dict):
        return None
    for key in ("v2", "v1"):
        value = drone.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def _read_drone_table_fallback(path: Path) -> Dict[str, str]:
    """Read simple quoted v1/v2 values when stdlib tomllib is unavailable."""
    values: Dict[str, str] = {}
    in_drone = False
    with path.open("r", encoding="utf-8") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("["):
                in_drone = line == "[drone]"
                continue
            if not in_drone or "=" not in line:
                continue
            key, encoded = line.split("=", 1)
            key = key.strip()
            if key not in {"v1", "v2"}:
                continue
            parsed = ast.literal_eval(encoded.strip())
            if isinstance(parsed, str):
                values[key] = parsed
    return values


def _read_config_ini_serial(path: Path) -> str | None:
    if not path.is_file():
        return None
    try:
        with path.open("r", encoding="utf-8") as f:
            return f.readline().strip() or None
    except OSError as exc:
        log.warning("serial source %s is not ready: %s", path, exc)
        return None


def resolve_serial(
    serial_source: str,
    *,
    config_toml_path: str | Path = DEFAULT_CONFIG_TOML,
    config_ini_path: str | Path = DEFAULT_CONFIG_INI,
) -> str | None:
    """Resolve a baked-image serial, returning None while provisioning is pending."""
    source = (serial_source or "").strip().lower()
    if source not in VALID_SERIAL_SOURCES:
        raise ValueError(
            f"serial_source must be one of {', '.join(sorted(VALID_SERIAL_SOURCES))}"
        )
    if source == "config_toml_v2":
        return _read_config_toml_serial(Path(config_toml_path))
    if source == "config_ini":
        return _read_config_ini_serial(Path(config_ini_path))
    machine_id = _machine_id()
    return f"pi-{machine_id}" if machine_id else None


def ensure_credentials(serial_file: str | Path, token_file: str | Path) -> Credentials:
    """
    Load existing device serial/token or generate them once.

    Never log the token. Log serial and a registration hint when creating new credentials.
    """
    serial_path = Path(serial_file)
    token_path = Path(token_file)

    serial = _read_stripped(serial_path)
    token = _read_stripped(token_path)

    if serial and token:
        return Credentials(serial=serial, token=token)

    if serial and not token:
        token = secrets.token_urlsafe(32)
        write_secret(token_path, token)
        log.warning(
            "Generated new device token for existing serial=%s; "
            "register (serial, token) in admin panel before uploads work",
            serial,
        )
        return Credentials(serial=serial, token=token)

    if token and not serial:
        serial = f"pi-{_machine_id_short()}"
        write_secret(serial_path, serial)
        log.warning(
            "Generated new device serial=%s for existing token file; "
            "register (serial, token) in admin panel before uploads work",
            serial,
        )
        return Credentials(serial=serial, token=token)

    serial = f"pi-{_machine_id_short()}"
    token = secrets.token_urlsafe(32)
    write_secret(serial_path, serial)
    write_secret(token_path, token)
    log.warning(
        "Generated device credentials serial=%s; "
        "register (serial, token) in admin → Collectors → Add drone. "
        "Token is in %s (mode 0600) — do not commit or share publicly.",
        serial,
        token_path,
    )
    return Credentials(serial=serial, token=token)
