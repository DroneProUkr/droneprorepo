#!/usr/bin/env python3
"""
Continuous ML data upload service for Raspberry Pi collectors.

Waits for network policy (Wi-Fi SSID allowlist, Ethernet link, or any) and a
reachable API, then splits each closed session into size-balanced tar.zst
archives (default up to 10), uploads via multipart ML Upload API with durable
two-level resume, and deletes local data only after all batches succeed.

Reusable across products: configure data_root, project, and session discovery
markers in upload.conf.
"""

from __future__ import annotations

import argparse
import logging
import signal
import sys
import time
from dataclasses import dataclass
from pathlib import Path

# Allow running as /usr/local/lib/ml-uploader/uploader.py without package install
_SERVICE_DIR = Path(__file__).resolve().parent
if str(_SERVICE_DIR) not in sys.path:
    sys.path.insert(0, str(_SERVICE_DIR.parent))

from upload_service.api_client import (  # noqa: E402
    AuthError,
    EnrollmentStatus,
    MlUploadClient,
    MultipartResumeState,
    PartETag,
)
from upload_service.archive import (  # noqa: E402
    create_batch_archive,
    remove_archive_file,
    remove_flight_and_archive,
)
from upload_service.batch_planner import plan_flight_batches  # noqa: E402
from upload_service.credentials import (  # noqa: E402
    DEFAULT_CONFIG_INI,
    DEFAULT_CONFIG_TOML,
    Credentials,
    ensure_credentials,
    load_config,
    parse_ssid_allowlist,
    persist_enrollment,
    read_private_secret,
    read_secret,
    resolve_serial,
    write_secret,
)
from upload_service.flights import list_closed_flights  # noqa: E402
from upload_service.network import (  # noqa: E402
    normalize_network_mode,
    upload_conditions_met,
)
from upload_service.upload_state import (  # noqa: E402
    STATUS_UPLOADED,
    UploadManifest,
    load_manifest,
    manifest_path,
    mark_batch_uploaded,
    save_manifest,
    update_multipart_parts,
)

log = logging.getLogger("ml_upload")

_shutdown = False

BOOTSTRAP_READY = "ready"
BOOTSTRAP_WAITING_SERIAL = "waiting_serial"
BOOTSTRAP_WAITING_ENROLLMENT = "waiting_enrollment"
BOOTSTRAP_REJECTED = "enrollment_rejected"
BOOTSTRAP_ALREADY_CLAIMED = "token_already_claimed"
BOOTSTRAP_MASTER_KEY_MISSING = "master_key_missing"


@dataclass(frozen=True)
class BootstrapResult:
    status: str
    credentials: Credentials | None = None


def _handle_signal(signum, _frame) -> None:
    global _shutdown
    log.info("received signal %s, shutting down after current work", signum)
    _shutdown = True


def setup_logging(verbose: bool = False) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )


def _data_root(cfg: dict) -> Path:
    return Path(cfg.get("data_root") or cfg.get("flights_root") or "/flights")


def _busy_markers(cfg: dict) -> list[str]:
    raw = cfg.get("busy_markers", "telemetry.db-wal,telemetry.db-shm")
    return [s.strip() for s in raw.split(",") if s.strip()]


def _target_batch_count(cfg: dict) -> int:
    raw = cfg.get("target_batch_count", "10")
    try:
        value = int(raw)
    except (TypeError, ValueError):
        value = 10
    return max(0, value)


def _closed_marker(cfg: dict) -> str:
    return cfg.get("closed_marker", "flight_metadata.json")


def _master_key_path(cfg: dict) -> Path | None:
    """A non-empty configured path opts the device into self-enrollment mode."""
    raw = (cfg.get("master_key_file") or "").strip()
    return Path(raw) if raw else None


def _contains_inline_master_key(config_path: Path) -> bool:
    """Detect any active non-empty legacy master_key entry without exposing it."""
    with config_path.open("r", encoding="utf-8") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            if key.strip() == "master_key" and value.strip():
                return True
    return False


def _credential_paths(cfg: dict) -> tuple[Path, Path]:
    return (
        Path(cfg.get("device_serial_file", "/etc/ml-uploader/device_serial")),
        Path(cfg.get("device_token_file", "/etc/ml-uploader/device_token")),
    )


def _pending_serial_path(cfg: dict, serial_path: Path) -> Path:
    raw = (cfg.get("enrollment_serial_file") or "").strip()
    return Path(raw) if raw else serial_path.with_name(
        f"{serial_path.name}.enrollment_pending"
    )


def bootstrap_credentials(
    cfg: dict,
    config_path: str | Path,
    *,
    config_toml_path: str | Path = DEFAULT_CONFIG_TOML,
    config_ini_path: str | Path = DEFAULT_CONFIG_INI,
) -> BootstrapResult:
    """Resolve manual credentials or advance one master-key enrollment attempt."""
    serial_path, token_path = _credential_paths(cfg)
    pending_serial_path = _pending_serial_path(cfg, serial_path)
    master_key_path = _master_key_path(cfg)
    token = read_secret(token_path)
    cached_serial = read_secret(serial_path)

    # A personal token always wins and must never trigger master-key fallback.
    if token:
        if cached_serial:
            return BootstrapResult(
                BOOTSTRAP_READY,
                Credentials(serial=cached_serial, token=token),
            )
        if master_key_path is None:
            return BootstrapResult(
                BOOTSTRAP_READY,
                ensure_credentials(serial_path, token_path),
            )

        serial = resolve_serial(
            cfg.get("serial_source", "config_toml_v2"),
            config_toml_path=config_toml_path,
            config_ini_path=config_ini_path,
        )
        if not serial:
            return BootstrapResult(BOOTSTRAP_WAITING_SERIAL)
        # Restore only the serial side of an existing personal credential pair.
        write_secret(serial_path, serial)
        return BootstrapResult(
            BOOTSTRAP_READY,
            Credentials(serial=serial, token=token),
        )

    # No configured master-key path is the unchanged legacy/manual mode.
    if master_key_path is None:
        return BootstrapResult(
            BOOTSTRAP_READY,
            ensure_credentials(serial_path, token_path),
        )

    # In baked mode never let a stale cached pi-* serial override provisioning.
    serial = read_private_secret(pending_serial_path)
    if not serial:
        serial = resolve_serial(
            cfg.get("serial_source", "config_toml_v2"),
            config_toml_path=config_toml_path,
            config_ini_path=config_ini_path,
        )
        if not serial:
            return BootstrapResult(BOOTSTRAP_WAITING_SERIAL)
        # Pin the first identity used for enroll so v1 -> v2 provisioning changes
        # cannot create a second server-side device between polling attempts.
        write_secret(pending_serial_path, serial)

    master_key = read_private_secret(master_key_path)
    if not master_key:
        log.error("configured master key file is missing or empty: %s", master_key_path)
        return BootstrapResult(BOOTSTRAP_MASTER_KEY_MISSING)

    project_hint = (cfg.get("project") or "").strip() or None
    enroll_client = MlUploadClient(cfg["api_base_url"], serial, token="")
    result = enroll_client.enroll(master_key, project=project_hint)

    if result.status == EnrollmentStatus.PENDING:
        log.info("device enrollment is pending operator approval serial=%s", serial)
        return BootstrapResult(BOOTSTRAP_WAITING_ENROLLMENT)
    if result.status == EnrollmentStatus.REJECTED:
        log.error("device enrollment was rejected by the operator serial=%s", serial)
        return BootstrapResult(BOOTSTRAP_REJECTED)
    if result.status == EnrollmentStatus.ALREADY_CLAIMED:
        log.error(
            "server token was already claimed for serial=%s but no local token exists; "
            "ask an operator to reissue it",
            serial,
        )
        return BootstrapResult(BOOTSTRAP_ALREADY_CLAIMED)

    assert result.status == EnrollmentStatus.APPROVED
    assert result.device_token is not None
    assert result.project is not None
    persist_enrollment(
        config_path,
        serial_path,
        token_path,
        serial,
        result.project,
        result.device_token,
        pending_serial_path=pending_serial_path,
    )
    # load_config() is not called again in the long-running process.
    cfg["project"] = result.project
    log.info(
        "device enrollment approved serial=%s project=%s; personal token persisted",
        serial,
        result.project,
    )
    return BootstrapResult(
        BOOTSTRAP_READY,
        Credentials(serial=serial, token=result.device_token),
    )


def _network_ready_for_bootstrap(cfg: dict) -> bool:
    allowlist = parse_ssid_allowlist(cfg.get("ssid_allowlist", ""))
    api_base = cfg["api_base_url"]
    network_mode = normalize_network_mode(cfg.get("network_mode", "wifi"))
    net = upload_conditions_met(api_base, allowlist, network_mode=network_mode)
    if net.ok:
        return True
    log.info(
        "enrollment waiting for network mode=%s ssid=%r eth=%r api_ok=%s reason=%s",
        net.mode,
        net.ssid,
        net.ethernet_iface,
        net.api_ok,
        net.reason,
    )
    return False


def _sleep_interruptibly(seconds: int) -> None:
    for _ in range(max(0, seconds)):
        if _shutdown:
            break
        time.sleep(1)


def _ensure_manifest(
    flight_dir: Path,
    work_dir: Path,
    target_batch_count: int,
    client: MlUploadClient,
) -> UploadManifest:
    """Load manifest or create from planner; abort stale multipart on hash mismatch."""
    path = manifest_path(work_dir, flight_dir.name)
    plan = plan_flight_batches(flight_dir, target_batch_count=target_batch_count)
    existing = load_manifest(path)

    if existing is not None and existing.plan_hash == plan.plan_hash:
        return existing

    if existing is not None:
        log.warning(
            "plan_hash mismatch for %s (was %s… now %s…); rebuilding plan",
            flight_dir.name,
            existing.plan_hash[:12],
            plan.plan_hash[:12],
        )
        for batch in existing.batches:
            mp = batch.multipart
            if mp is not None:
                client.abort(mp.key, mp.upload_id)

    manifest = UploadManifest.from_flight_plan(plan)
    save_manifest(path, manifest)
    return manifest


def process_one_flight(
    flight_dir: Path,
    work_dir: Path,
    client: MlUploadClient,
    content_type: str,
    part_size: int,
    dry_run: bool,
    project: str | None = None,
    target_batch_count: int = 10,
    closed_marker: str = "flight_metadata.json",
) -> bool:
    """
    Archive+upload all batches for one closed session. Returns True on full success.

    Progress is persisted under work_dir/<flight>/manifest.json so a later poll
    can resume which archive and which multipart parts remain.
    """
    log.info(
        "processing session %s project=%s target_batch_count=%d",
        flight_dir.name,
        project or "(default)",
        target_batch_count,
    )
    if dry_run:
        plan = plan_flight_batches(flight_dir, target_batch_count=target_batch_count)
        for b in plan.batches:
            log.info(
                "[dry-run] would upload %s (%d files, ~%d bytes)",
                b.filename,
                len(b.files),
                b.uncompressed_bytes,
            )
        return True

    manifest = _ensure_manifest(flight_dir, work_dir, target_batch_count, client)
    mpath = manifest_path(work_dir, flight_dir.name)

    for batch_state in manifest.batches:
        if _shutdown:
            log.info("shutdown requested; leaving remaining batches for next run")
            return False
        if batch_state.status == STATUS_UPLOADED:
            log.info("skipping already uploaded batch %s", batch_state.id)
            continue

        batch_plan = batch_state.to_batch_plan()
        archive_path = work_dir / flight_dir.name / batch_state.filename
        if not archive_path.is_file():
            archive_path = create_batch_archive(
                flight_dir,
                work_dir,
                batch_plan,
                closed_marker=closed_marker,
            )

        resume = None
        if batch_state.multipart is not None:
            mp = batch_state.multipart
            resume = MultipartResumeState(
                key=mp.key,
                upload_id=mp.upload_id,
                part_size=mp.part_size,
                parts=[
                    PartETag(part_number=int(p["part_number"]), etag=str(p["etag"]))
                    for p in mp.parts
                ],
            )
            # If checkpoint part_size differs from current config, abort and restart
            if mp.part_size != part_size:
                log.warning(
                    "part_size changed for %s; aborting checkpoint and restarting",
                    batch_state.id,
                )
                client.abort(mp.key, mp.upload_id)
                batch_state.multipart = None
                save_manifest(mpath, manifest)
                resume = None

        def _on_checkpoint(state: MultipartResumeState, _bid=batch_state.id) -> None:
            update_multipart_parts(
                manifest,
                _bid,
                state.parts_as_dicts(),
                key=state.key,
                upload_id=state.upload_id,
                part_size=state.part_size,
            )
            save_manifest(mpath, manifest)

        try:
            meta = client.upload_file_resumable(
                archive_path,
                content_type=content_type or None,
                part_size=part_size,
                project=project,
                resume=resume,
                on_checkpoint=_on_checkpoint,
                abort_on_failure=False,
            )
        except AuthError:
            raise
        except Exception:
            # Checkpoint already saved by on_checkpoint for completed parts
            raise

        remote_id = meta.get("id")
        if remote_id is not None:
            try:
                remote_id = int(remote_id)
            except (TypeError, ValueError):
                remote_id = None
        mark_batch_uploaded(manifest, batch_state.id, remote_id=remote_id)
        save_manifest(mpath, manifest)
        remove_archive_file(archive_path)
        log.info("batch %s uploaded remote_id=%s", batch_state.id, remote_id)

    if not manifest.all_uploaded():
        return False

    remove_flight_and_archive(
        flight_dir,
        archive_path=None,
        work_subdir=work_dir / flight_dir.name,
    )
    return True


def run_once(cfg: dict, creds, dry_run: bool = False) -> str:
    """
    Single poll cycle.

    Returns status: 'idle_network' | 'idle_empty' | 'uploaded' | 'auth_error' | 'error'
    """
    allowlist = parse_ssid_allowlist(cfg.get("ssid_allowlist", ""))
    api_base = cfg["api_base_url"]
    network_mode = normalize_network_mode(cfg.get("network_mode", "wifi"))
    net = upload_conditions_met(api_base, allowlist, network_mode=network_mode)

    if not net.ok:
        log.info(
            "upload conditions not met mode=%s ssid=%r eth=%r allowlist=%s "
            "api_ok=%s reason=%s",
            net.mode,
            net.ssid,
            net.ethernet_iface,
            allowlist,
            net.api_ok,
            net.reason,
        )
        return "idle_network"

    log.info(
        "upload conditions met mode=%s ssid=%r eth=%r",
        net.mode,
        net.ssid,
        net.ethernet_iface,
    )

    root = _data_root(cfg)
    closed = list_closed_flights(
        root,
        dir_prefix=cfg.get("dir_prefix", "flight_"),
        closed_marker=_closed_marker(cfg),
        busy_markers=_busy_markers(cfg),
    )
    if not closed:
        log.info("no closed sessions under %s", root)
        return "idle_empty"

    log.info("found %d closed session(s)", len(closed))
    target_batches = _target_batch_count(cfg)
    if dry_run:
        for f in closed:
            log.info("[dry-run] candidate %s", f)
            plan = plan_flight_batches(f, target_batch_count=target_batches)
            for b in plan.batches:
                log.info(
                    "[dry-run] would upload %s (%d files, ~%d bytes)",
                    b.filename,
                    len(b.files),
                    b.uncompressed_bytes,
                )
        return "idle_empty"

    work_dir = Path(cfg.get("work_dir", "/var/tmp/ml-upload"))
    part_mib = int(cfg.get("part_size_mib", "8"))
    part_size = max(part_mib, 5) * 1024 * 1024
    content_type = cfg.get("content_type", "application/zstd")
    project = (cfg.get("project") or "").strip() or None
    closed_marker = _closed_marker(cfg)

    client = MlUploadClient(api_base, creds.serial, creds.token)
    uploaded_any = False
    for flight_dir in closed:
        if _shutdown:
            break
        try:
            if process_one_flight(
                flight_dir,
                work_dir,
                client,
                content_type,
                part_size,
                dry_run=False,
                project=project,
                target_batch_count=target_batches,
                closed_marker=closed_marker,
            ):
                uploaded_any = True
        except AuthError as exc:
            log.error("%s", exc)
            return "auth_error"
        except Exception as exc:
            log.exception("failed to upload %s: %s", flight_dir.name, exc)
            return "error"

    return "uploaded" if uploaded_any else "idle_empty"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="ML session upload service (multipart API client)"
    )
    parser.add_argument(
        "config",
        nargs="?",
        default="/etc/ml-uploader/upload.conf",
        help="path to upload.conf",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="check network and list closed sessions; do not upload or delete",
    )
    parser.add_argument(
        "--once",
        action="store_true",
        help="run a single poll cycle and exit",
    )
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args(argv)

    setup_logging(args.verbose)
    signal.signal(signal.SIGTERM, _handle_signal)
    signal.signal(signal.SIGINT, _handle_signal)

    cfg_path = Path(args.config)
    if not cfg_path.is_file():
        log.error("config not found: %s", cfg_path)
        return 2

    cfg = load_config(cfg_path)
    for required in ("api_base_url",):
        if required not in cfg:
            log.error("missing required config key: %s", required)
            return 2
    if _contains_inline_master_key(cfg_path):
        log.error(
            "inline master_key is forbidden; move it to a root-only file and set "
            "master_key_file instead"
        )
        return 2

    log.info(
        "network_mode=%s ssid_allowlist=%s project=%s data_root=%s "
        "target_batch_count=%d",
        normalize_network_mode(cfg.get("network_mode", "wifi")),
        parse_ssid_allowlist(cfg.get("ssid_allowlist", "")),
        (cfg.get("project") or "").strip() or "(server default)",
        _data_root(cfg),
        _target_batch_count(cfg),
    )

    poll = int(cfg.get("poll_interval_sec", "60"))
    auth_backoff = int(cfg.get("auth_backoff_sec", "3600"))

    creds: Credentials | None = None
    if _master_key_path(cfg) is None:
        # Preserve the previous manual-mode startup behavior exactly.
        boot = bootstrap_credentials(cfg, cfg_path)
        assert boot.credentials is not None
        creds = boot.credentials
        log.info("device serial=%s authentication_mode=manual", creds.serial)

    # Master-key dry runs do not enroll. Manual dry runs retain legacy credential
    # generation performed above, but neither mode uploads or deletes data.
    if args.dry_run:
        dry_creds = creds or Credentials(serial="", token="")
        status = run_once(cfg, dry_creds, dry_run=True)
        return 1 if status == "error" else 0

    if args.once:
        if creds is None:
            if not _network_ready_for_bootstrap(cfg):
                return 0
            try:
                boot = bootstrap_credentials(cfg, cfg_path)
            except Exception as exc:
                log.exception("credential bootstrap failed: %s", exc)
                return 1
            if boot.status != BOOTSTRAP_READY or boot.credentials is None:
                return 0 if boot.status in {
                    BOOTSTRAP_WAITING_SERIAL,
                    BOOTSTRAP_WAITING_ENROLLMENT,
                } else 1
            creds = boot.credentials
            log.info("device serial=%s authentication_mode=personal", creds.serial)

        status = run_once(cfg, creds, dry_run=False)
        if status == "auth_error":
            return 1
        if status == "error":
            return 1
        return 0

    log.info("starting upload loop poll_interval_sec=%d", poll)
    while not _shutdown:
        if creds is None:
            if not _network_ready_for_bootstrap(cfg):
                _sleep_interruptibly(poll)
                continue
            try:
                boot = bootstrap_credentials(cfg, cfg_path)
            except Exception as exc:
                log.exception("credential bootstrap failed: %s", exc)
                _sleep_interruptibly(auth_backoff)
                continue

            if boot.status != BOOTSTRAP_READY or boot.credentials is None:
                delay = (
                    poll
                    if boot.status == BOOTSTRAP_WAITING_SERIAL
                    else auth_backoff
                )
                log.info(
                    "credential bootstrap status=%s; retrying in %d seconds",
                    boot.status,
                    delay,
                )
                _sleep_interruptibly(delay)
                continue
            creds = boot.credentials
            log.info("device serial=%s authentication_mode=personal", creds.serial)

        status = run_once(cfg, creds, dry_run=False)
        if status == "auth_error":
            log.error(
                "backing off %d seconds after auth failure "
                "(verify or reissue the device credentials)",
                auth_backoff,
            )
            _sleep_interruptibly(auth_backoff)
            continue

        _sleep_interruptibly(poll)

    log.info("exited cleanly")
    return 0


if __name__ == "__main__":
    sys.exit(main())
